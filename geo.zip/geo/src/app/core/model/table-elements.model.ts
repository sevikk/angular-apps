export interface ITableElements {
  place: string;
  mag: number;
  time: number;
  sig: number;
  url: string;
}
